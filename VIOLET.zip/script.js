// =========================================
// 1. FLOATING HEARTS
// =========================================
(function createFloatingHearts() {
    const container = document.getElementById('floatingHearts');
    const emojis = ['❤️', '💖', '✨', '🌸', '🌹', '💕', '🌺'];
    for (let i = 0; i < 18; i++) {
        const span = document.createElement('span');
        span.textContent = emojis[Math.floor(Math.random() * emojis.length)];
        span.style.left = Math.random() * 100 + '%';
        span.style.fontSize = (16 + Math.random() * 24) + 'px';
        span.style.animationDelay = (Math.random() * 12) + 's';
        span.style.animationDuration = (10 + Math.random() * 8) + 's';
        container.appendChild(span);
    }
})();

// =========================================
// 2. QUOTES SLIDER
// =========================================
const quotes = [{
    text: '"Cinta bukan tentang menemukan seseorang yang sempurna, tapi tentang melihat ketidaksempurnaan dengan sempurna."',
    author: '— Rumi'
}, {
    text: '"Kamu adalah puisi yang tak pernah usang, dan aku ingin membacamu sepanjang hidup."',
    author: '— Kahlil Gibran'
}, {
    text: '"Dalam setiap kenangan, ada senyummu yang menjadi bintang di langit malamku."',
    author: '— Penulis Anonim'
}, {
    text: '"Cinta adalah ketika kebahagiaan seseorang lebih penting daripada kebahagiaanmu sendiri."',
    author: '— H. Jackson Brown Jr.'
}, {
    text: '"Bersamamu, aku belajar bahwa cinta bukan hanya perasaan, tapi keputusan untuk tetap memilih."',
    author: '— Penulis Anonim'
}, {
    text: '"Kenangan indah adalah harta yang tak pernah bisa dicuri waktu."',
    author: '— Penulis Anonim'
}];

let currentQuote = 0;
const quoteText = document.getElementById('quoteText');
const quoteAuthor = document.getElementById('quoteAuthor');
const dotsContainer = document.getElementById('quoteDots');

// Buat dots
quotes.forEach((_, i) => {
    const dot = document.createElement('span');
    dot.classList.toggle('active', i === 0);
    dot.dataset.index = i;
    dot.addEventListener('click', () => goToQuote(i));
    dotsContainer.appendChild(dot);
});

function updateQuote(index) {
    currentQuote = index;
    quoteText.style.opacity = '0';
    setTimeout(() => {
        quoteText.textContent = quotes[index].text;
        quoteAuthor.textContent = quotes[index].author;
        quoteText.style.opacity = '1';
    }, 300);

    document.querySelectorAll('.quote-dots span').forEach((dot, i) => {
        dot.classList.toggle('active', i === index);
    });
}

function goToQuote(index) {
    if (index < 0) index = quotes.length - 1;
    if (index >= quotes.length) index = 0;
    updateQuote(index);
}

document.getElementById('nextQuote').addEventListener('click', () => goToQuote(currentQuote + 1));
document.getElementById('prevQuote').addEventListener('click', () => goToQuote(currentQuote - 1));

// Auto-slide
let autoSlide = setInterval(() => goToQuote(currentQuote + 1), 5000);

// Reset timer saat interaksi
document.querySelectorAll('.quote-controls button').forEach(btn => {
    btn.addEventListener('click', () => {
        clearInterval(autoSlide);
        autoSlide = setInterval(() => goToQuote(currentQuote + 1), 5000);
    });
});

// =========================================
// 3. SURAT (Buka / Tutup)
// =========================================
const letterContent = document.getElementById('letterContent');
const letterBtn = document.getElementById('letterBtn');
let letterOpen = false;

letterBtn.addEventListener('click', () => {
    letterOpen = !letterOpen;
    letterContent.classList.toggle('open', letterOpen);
    letterBtn.innerHTML = letterOpen ?
        '<i class="fas fa-envelope"></i> Tutup Surat' :
        '<i class="fas fa-envelope-open-text"></i> Buka Surat';
});

// =========================================
// 4. SCROLL ANIMATION (Intersection Observer)
// =========================================
const fadeElements = document.querySelectorAll('.fade-up');

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, {
    threshold: 0.15,
    rootMargin: '0px 0px -40px 0px'
});

fadeElements.forEach(el => observer.observe(el));

// =========================================
// 5. NAVBAR SCROLL EFFECT
// =========================================
const header = document.querySelector('header');
window.addEventListener('scroll', () => {
    if (window.scrollY > 60) {
        header.style.boxShadow = '0 4px 30px rgba(0,0,0,0.08)';
    } else {
        header.style.boxShadow = '0 2px 20px rgba(0,0,0,0.06)';
    }
});

// =========================================
// 6. SMOOTH NAV CLICK (tanpa hash jump)
// =========================================
document.querySelectorAll('nav a').forEach(link => {
    link.addEventListener('click', (e) => {
        const targetId = link.getAttribute('href');
        if (targetId && targetId.startsWith('#')) {
            e.preventDefault();
            const target = document.querySelector(targetId);
            if (target) {
                const offset = 80;
                const top = target.getBoundingClientRect().top + window.scrollY - offset;
                window.scrollTo({ top, behavior: 'smooth' });
            }
        }
    });
});

console.log('❤️ Website Kenangan & Kata Romantis siap!');